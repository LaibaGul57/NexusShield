# from fastapi import FastAPI, Request, HTTPException, Query
# from fastapi.middleware.cors import CORSMiddleware
# from fastapi.responses import JSONResponse
# from pymongo import MongoClient
# from datetime import datetime
# from pydantic import BaseModel
# import uvicorn
# from bson import ObjectId
# from pydantic import BaseModel
# # ✅ Existing Imports
# from ai_model import predict_url
# from flashcard import get_topic_data, save_user_quiz_score, HARDCODED_TOPICS
# from routes.all_routes import router as all_routes_router

# app = FastAPI()

# # ✅ Routers
# app.include_router(all_routes_router, prefix="/api")

# # ✅ MongoDB Connection
# try:
#     client = MongoClient(
#         "mongodb+srv://nexus_user1:4PAiHn%219B%25D.uDM@cluster0.begtxob.mongodb.net/nexusshield?retryWrites=true&w=majority&appName=Cluster0"
#     )
#     db = client["nexusshield"]
#     users_collection = db["users"]
#     quiz_scores_collection = db["quizscores"]
#     progress_collection = db["progress"]
    
#     db_cyber = client["cyber_training"]
#     topics_collection = db_cyber["topics"]
    
#     print("✅ MongoDB connected successfully!")
# except Exception as e:
#     print("❌ MongoDB connection failed:", e)

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # -----------------------------------------------------------
# # ✅ URL PREDICTION (LINK CHECKER)
# # -----------------------------------------------------------

# class URLRequest(BaseModel):
#     url: str  # ✅ "text" ki jagah "url" use karo
# class Stat(BaseModel):
#     name: str  # Example: "Mon", "Tue"
#     value: int
# @app.post("/predict")
# def predict_url_endpoint(data: URLRequest):
#     try:
#         # 1. Sab se pehle link check karo (AI Model
#         result = predict_url(data.url)

#         # 2. Statistics Update (Alag se try block mein taake error na aaye)
#         try:
#             today_name = datetime.now().strftime("%a") 
#             db["stats"].update_one(
#                 {"name": today_name},
#                 {
#                     "$inc": {"value": 1},
#                     "$setOnInsert": {"__v": 0}
#                 },
#                 upsert=True
#             )
#             print(f"📊 Stats updated for {today_name}")
#         except Exception as stats_err:
#             print(f"⚠️ Stats Update Error (Silent): {stats_err}")

#         # 3. YAHAN HAI ASAL CHEEZ: Result return karna
#         # Ye line 'try' ke andar lekin 'stats' ke bahar honi chahiye
#         return result

#     except Exception as e:
#         print(f"❌ Main Error: {e}")
#         return {
#             "label": "❌ ERROR",
#             "probability": 0.5,
#             "error": str(e)
#         }
# # -----------------------------------------------------------
# # ✅ TRAINING & PROGRESS ROUTES
# # -----------------------------------------------------------

# @app.get("/topics/{level}")
# async def get_level_topics(level: int):
#     topics = HARDCODED_TOPICS.get(level, [])
#     if not topics:
#         return JSONResponse({"topics": [], "message": "Level not found"}, status_code=404)
#     return {"topics": topics}

# @app.get("/get-content")
# async def get_content(topic: str, level: int):
#     clean_topic = topic.strip()
#     try:
#         content = get_topic_data(clean_topic, level)
#         if content:
#             return content
#         return JSONResponse(status_code=404, content={"error": "Not found"})
#     except Exception as e:
#         return JSONResponse(status_code=500, content={"error": str(e)})

# @app.get("/api/progress/{user_id}")
# async def get_user_progress(user_id: str):
#     try:
#         progress_data = db["progress"].find_one({"user_id": user_id}, {"_id": 0})
#         if progress_data:
#             return progress_data
#         return {"lessonsCompleted": 0, "quizzesAttempted": 0, "quizScore": 0, "nudgesReceived": 0}
#     except Exception as e:
#         return JSONResponse(status_code=500, content={"error": str(e)})

# @app.post("/api/save-quiz-result")
# async def save_quiz_result(request: Request):
#     try:
#         data = await request.json()
#         user_id, score_val, total_val = data.get("user_id"), data.get("score"), data.get("total")
#         db["quizscores"].insert_one({"range": f"{score_val}/{total_val}", "score": score_val, "__v": 0}) 
#         db["progress"].update_one(
#             {"user_id": user_id},
#             {"$inc": {"lessonsCompleted": 1, "quizzesAttempted": 1}, "$set": {"quizScore": score_val}},
#             upsert=True 
#         )
#         return {"status": "success"}
#     except Exception as e:
#         return JSONResponse(status_code=500, content={"error": str(e)})

# # -----------------------------------------------------------
# # ✅ AUTHENTICATION
# # -----------------------------------------------------------

# @app.post("/signup")
# async def signup(request: Request):
#     data = await request.json()
#     email = data.get("email")
#     if users_collection.find_one({"email": email}):
#         return JSONResponse({"message": "User already exists"}, status_code=400)
#     users_collection.insert_one({
#         "name": data.get("name"), "email": email, "password": data.get("password"),
#         "role": data.get("role"), "createdAt": datetime.utcnow()
#     })
#     return JSONResponse({"message": "User registered successfully"}, status_code=200)

# # @app.post("/login")
# # async def login(request: Request):
# #     data = await request.json()
# #     user = users_collection.find_one({"email": data.get("email"), "password": data.get("password")})
# #     if not user:
# #         return JSONResponse({"message": "Invalid credentials"}, status_code=401)
# #     return {"message": "Login successful", "user": {"name": user.get("name"), "user_id": str(user.get("_id"))}}
# @app.post("/login")
# async def login(request: Request):
#     data = await request.json()
#     email = data.get("email")
#     password = data.get("password")

#     # 1. Database mein user check karein
#     user = users_collection.find_one({"email": email, "password": password})
    
#     if not user:
#         # Agar user nahi mila toh 401 error bhejien
#         return JSONResponse({"message": "Invalid credentials"}, status_code=401)
    
#     # 2. Return data (Aapke purane style mein)
#     # Humne sirf "surveyDone" add kiya hai jo database se uthayega
#     return {
#         "message": "Login successful", 
#         "user": {
#             "name": user.get("name"), 
#             "email": user.get("email"),
#             "user_id": str(user.get("_id")),
#             "surveyDone": user.get("surveyDone", False) # Agar field nahi hai toh False return karega
#         }
#     }
# # -----------------------------------------------------------
# # ✅ SAVE SURVEY RESULTS & CALCULATE LEVEL
# # -----------------------------------------------------------

# @app.post("/survey")
# async def save_survey(request: Request):
#     try:
#         # 1. Frontend se data receive karein
#         data = await request.json()
#         user_id = data.get("userId")
#         answers = data.get("answers") # Expecting dictionary: {"T1": 5, "T2": 3, ...}

#         if not user_id or not answers:
#             return JSONResponse(status_code=400, content={"message": "User ID or Answers missing"})

#         # 2. Total Score calculation (14 questions, max 5 each = 70)
#         total_score = sum(answers.values())
        
#         # 3. Level Logic based on Cyber Hygiene Score
#         if total_score <= 30:
#             level = 1  # Beginner
#         elif total_score <= 55:
#             level = 2  # Intermediate
#         else:
#             level = 3  # Advanced

#         # 4. Update User Profile in "users" collection
#         # Hum surveyDone ko True kar rahe hain aur level save kar rahe hain
#         users_collection.update_one(
#             {"_id": ObjectId(user_id)},
#             {
#                 "$set": {
#                     "level": level, 
#                     "surveyDone": True, 
#                     "total_score": total_score,
#                     "last_updated": datetime.utcnow()
#                 }
#             }
#         )

#         # 5. Initialize/Update Progress in "progress" collection
#         # Taake user dashboard par apni progress dekh sakay
#         progress_collection.update_one(
#             {"user_id": user_id},
#             {
#                 "$set": {
#                     "level": level,
#                     "lessonsCompleted": 0,
#                     "quizzesAttempted": 0,
#                     "quizScore": 0,
#                     "nudgesReceived": 0
#                 }
#             },
#             upsert=True  # Agar record nahi hai toh naya bana dega
#         )

#         # 6. Success Response (Frontend ko percentage aur level bhej rahe hain)
#         return {
#             "status": "success", 
#             "level": level, 
#             "percentage": round((total_score / 70) * 100),
#             "message": "Survey saved and level assigned!"
#         }

#     except Exception as e:
#         print(f"❌ Survey Error: {str(e)}")
#         return JSONResponse(
#             status_code=500, 
#             content={"message": "Internal Server Error", "error": str(e)}
#         )
# if __name__ == "__main__":
#     uvicorn.run(app, host="0.0.0.0", port=8000) 
from fastapi import FastAPI, Request, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pymongo import MongoClient
from datetime import datetime
from pydantic import BaseModel
import uvicorn
import firebase_admin
from firebase_admin import credentials, messaging
from bson import ObjectId
# ✅ Existing Imports
from ai_model import predict_url
from flashcard import get_topic_data, save_user_quiz_score, HARDCODED_TOPICS
from routes.all_routes import router as all_routes_router
from nudge_logic import get_initial_nudge_stats, select_best_category, is_it_time_to_send
import requests
from apscheduler.schedulers.background import BackgroundScheduler
import asyncio
from bson import ObjectId
# EXPO_PUSH_TOKEN = "ExponentPushToken[nE0c50P2V6FDyl7BSE_-mt]"
cred = credentials.Certificate("firebase-key.json")
if not firebase_admin._apps:
    firebase_admin.initialize_app(cred)

# --- Phir aapka Function ---
def send_fcm_nudge(token, title, body, category, user_id):
    # Sirf Data bhejni hai taake Notifee trigger ho
    message = messaging.Message(
        data={
            "title": title,          # Frontend yahan se title uthayega
            "body": body,            # Frontend yahan se body uthayega
            "userId": str(user_id),
            "category": category,
            "action_type": "nudge_response"
        },
        token=token,
    )
    
    try:
        response = messaging.send(message)
        print(f"🚀 FCM Nudge Sent ({category}):", response)
        return True
    except Exception as e:
        print(f"❌ FCM Error details: {e}")
        return False
app = FastAPI()
# ✅ Routers
app.include_router(all_routes_router, prefix="/api")

# ✅ MongoDB Connection
try:
    client = MongoClient(
        "mongodb+srv://nexus_user1:4PAiHn%219B%25D.uDM@cluster0.begtxob.mongodb.net/nexusshield?retryWrites=true&w=majority&appName=Cluster0"
    )
    db = client["nexusshield"]
    users_collection = db["users"]
    quiz_scores_collection = db["quizscores"]
    progress_collection = db["progress"]
    
    db_cyber = client["cyber_training"]
    topics_collection = db_cyber["topics"]
 
    print("✅ MongoDB connected successfully!")
except Exception as e:
    print("❌ MongoDB connection failed:", e)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# -----------------------------------------------------------
# ✅ db of model
# -----------------------------------------------------------
@app.get("/test-db")
def test_connection():
    try:
        # Ye line check karti hai ke Atlas ne respond kiya ya nahi
        client.admin.command('ping')
        return {"status": "success", "message": "connected sucessfulyy."}
    except Exception as e:
        return {"status": "error", "message": f"Connection Fail: {str(e)}"}
# -----------------------------------------------------------
# ✅ URL PREDICTION (LINK CHECKER)
# -----------------------------------------------------------

class URLRequest(BaseModel):
    url: str  # ✅ "text" ki jagah "url" use karo
class Stat(BaseModel):
    name: str  # Example: "Mon", "Tue"
    value: int
@app.post("/predict")
def predict_url_endpoint(data: URLRequest):
    try:
        # 1. Sab se pehle link check karo (AI Model
        result = predict_url(data.url)

        # 2. Statistics Update (Alag se try block mein taake error na aaye)
        try:
            today_name = datetime.now().strftime("%a") 
            db["stats"].update_one(
                {"name": today_name},
                {
                    "$inc": {"value": 1},
                    "$setOnInsert": {"__v": 0}
                },
                upsert=True
            )
            print(f"📊 Stats updated for {today_name}")
        except Exception as stats_err:
            print(f"⚠️ Stats Update Error (Silent): {stats_err}")

        # 3. YAHAN HAI ASAL CHEEZ: Result return karna
        # Ye line 'try' ke andar lekin 'stats' ke bahar honi chahiye
        return result

    except Exception as e:
        print(f"❌ Main Error: {e}")
        return {
            "label": "❌ ERROR",
            "probability": 0.5,
            "error": str(e)
        }
# -----------------------------------------------------------
# ✅ TRAINING & PROGRESS ROUTES
# -----------------------------------------------------------

@app.get("/topics/{level}")
async def get_level_topics(level: int):
    topics = HARDCODED_TOPICS.get(level, [])
    if not topics:
        return JSONResponse({"topics": [], "message": "Level not found"}, status_code=404)
    return {"topics": topics}

@app.get("/get-content")
async def get_content(topic: str, level: int):
    clean_topic = topic.strip()
    try:
        content = get_topic_data(clean_topic, level)
        if content:
            return content
        return JSONResponse(status_code=404, content={"error": "Not found"})
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@app.get("/api/progress/{user_id}")
async def get_user_progress(user_id: str):
    try:
        progress_data = db["progress"].find_one({"user_id": user_id}, {"_id": 0})
        if progress_data:
            return progress_data
        return {"lessonsCompleted": 0, "quizzesAttempted": 0, "quizScore": 0, "nudgesReceived": 0}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@app.post("/api/save-quiz-result")
async def save_quiz_result(request: Request):
    try:
        data = await request.json()
        user_id, score_val, total_val = data.get("user_id"), data.get("score"), data.get("total")
        db["quizscores"].insert_one({"range": f"{score_val}/{total_val}", "score": score_val, "__v": 0}) 
        db["progress"].update_one(
            {"user_id": user_id},
            {"$inc": {"lessonsCompleted": 1, "quizzesAttempted": 1}, "$set": {"quizScore": score_val}},
            upsert=True 
        )
        return {"status": "success"}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

# -----------------------------------------------------------
# ✅ AUTHENTICATION
# -----------------------------------------------------------

# @app.post("/signup")
# async def signup(request: Request):
#     data = await request.json()
#     email = data.get("email")
#     if users_collection.find_one({"email": email}):
#         return JSONResponse({"message": "User already exists"}, status_code=400)
#     users_collection.insert_one({
#         "name": data.get("name"), "email": email, "password": data.get("password"),
#         "role": data.get("role"), "createdAt": datetime.utcnow()
#     })
#     return JSONResponse({"message": "User registered successfully"}, status_code=200)
@app.post("/signup")
async def signup(request: Request):
    data = await request.json()
    email = data.get("email")
    if users_collection.find_one({"email": email}):
        return JSONResponse({"message": "User already exists"}, status_code=400)
    users_collection.insert_one({
        "name": data.get("name"), "email": email, "password": data.get("password"),
        "fcm_token": data.get("fcm_token"),
        "role": data.get("role"), "createdAt": datetime.utcnow(),
        "surveyDone": False,
    })
    return JSONResponse({"message": "User registered successfully"}, status_code=200)

@app.post("/login")
async def login(request: Request):
    data = await request.json()
    email = data.get("email")
    password = data.get("password")
    fcm_token = data.get("fcm_token")
    user = users_collection.find_one({"email": email, "password": password})
    
    if not user:
        # Agar user nahi mila toh 401 error bhejien
        return JSONResponse({"message": "Invalid credentials"}, status_code=401)
    
    if fcm_token:
      users_collection.update_one(
        {"_id": user["_id"]},
        {"$set": {"fcm_token": fcm_token}}
    )
    print(f"✅ FCM Token updated for {email}")
    # 2. Return data (Aapke purane style mein)
    # Humne sirf "surveyDone" add kiya hai jo database se uthayega
    return {
        "message": "Login successful", 
        "user": {
            "name": user.get("name"), 
            "email": user.get("email"),
            "user_id": str(user.get("_id")),
            "surveyDone": user.get("surveyDone", False) # Agar field nahi hai toh False return karega
        }
    }

# -----------------------------------------------------------
# ✅ SAVE SURVEY RESULTS & CALCULATE LEVEL
# -----------------------------------------------------------

@app.post("/survey")
async def save_survey(request: Request):
    try:
        # 1. Frontend se data receive karein
        data = await request.json()
        user_id = data.get("userId")
        answers = data.get("answers") # Expecting dictionary: {"T1": 5, "T2": 3, ...}

        if not user_id or not answers:
            return JSONResponse(status_code=400, content={"message": "User ID or Answers missing"})

        # 2. Total Score calculation (14 questions, max 5 each = 70)
        total_score = sum(answers.values())
        
        # 3. Level Logic based on Cyber Hygiene Score
        if total_score <= 30:
            level = 1  # Beginner
        elif total_score <= 55:
            level = 2  # Intermediate
        else:
            level = 3  # Advanced

        # 4. Update User Profile in "users" collection
        # Hum surveyDone ko True kar rahe hain aur level save kar rahe hain
       # 4. Update User Profile with Adaptive Nudge Stats
        users_collection.update_one(
            {"_id": ObjectId(user_id)},
            {
                "$set": {
                    "level": level, 
                    "surveyDone": True, 
                    "total_score": total_score,
                    "last_updated": datetime.utcnow(),
                    
                    # --- Naye Fields jo humne add kiye ---
                    "nudge_stats": get_initial_nudge_stats(), # nudge_logic.py se call ho raha hai
                    "daily_frequency": 8 if level == 1 else (6 if level == 2 else 4),
                    "last_nudge_sent_at": None,
                    "success_rate": 0.0
                }
            }
        )

        # 5. Initialize/Update Progress in "progress" collection
        # Taake user dashboard par apni progress dekh sakay
        progress_collection.update_one(
            {"user_id": user_id},
            {
                "$set": {
                    "level": level,
                    "lessonsCompleted": 0,
                    "quizzesAttempted": 0,
                    "quizScore": 0,
                    "nudgesReceived": 0
                }
            },
            upsert=True  # Agar record nahi hai toh naya bana dega
        )

        # 6. Success Response (Frontend ko percentage aur level bhej rahe hain)
        return {
            "status": "success", 
            "level": level, 
            "percentage": round((total_score / 70) * 100),
            "message": "Survey saved and level assigned!"
        }

    except Exception as e:
        print(f"❌ Survey Error: {str(e)}")
        return JSONResponse(
            status_code=500, 
            content={"message": "Internal Server Error", "error": str(e)}
        )
    # -----------------------------------------------------------
# -----------------------------------------------------------
# ✅ REAL-TIME AI NUDGE ENGINE (Thompson Sampling)
# -----------------------------------------------------------

@app.get("/api/get-nudge/{user_id}")
async def get_nudge(user_id: str):
    try:
        # 1. User fetch karein
        user = users_collection.find_one({"_id": ObjectId(user_id)})
        if not user:
            return {"status": "error", "message": "User not found"}

        # 2. Variable ko pehle hi initialize kar dein (Taake 'not associated' wala error na aaye)
        current_stats = user.get("nudge_stats")

        # 3. Agar stats missing hain toh foran naye banayein aur DB mein save karein
        if current_stats is None:
            print(f"⚠️ Stats missing for user {user_id}, initializing...")
            current_stats = get_initial_nudge_stats()
            users_collection.update_one(
                {"_id": ObjectId(user_id)},
                {"$set": {"nudge_stats": current_stats}}
            )

        # 4. Ab select_best_category ko call karein
        best_cat = select_best_category(current_stats)
        
        # 5. DB se message uthayein
        random_nudge = db["nudges"].find_one({
            "category": best_cat, 
            "level": user.get("level", 1) # Default level 1 agar missing ho
        })

        if not random_nudge:
            return {"status": "error", "message": f"No nudge content for {best_cat}"}

        # 6. Notification send
        # Naya FCM function call karein
        notification_sent = send_fcm_nudge(
            token=user.get("fcm_token"), # Database se token uthayen
            title=f"🛡️ Nexus Shield: {best_cat}", 
            body=random_nudge["message"],
            category=best_cat,    
            user_id=user_id       
        )

        # 7. Timestamp update
        users_collection.update_one(
            {"_id": ObjectId(user_id)},
            {"$set": {"last_nudge_sent_at": datetime.utcnow()}}
        )

        return {
            "status": "success",
            "category": best_cat,
            "message": random_nudge["message"],
            "notification_sent": notification_sent
        }

    except Exception as e:
        print(f"❌ Nudge Engine Error: {e}")
        return {"status": "error", "message": str(e)}
#----------------------------------------------
#-------get interaction-------
# 👈 Yahan koi space nahi honi chahiye
@app.post("/api/nudge-interaction")
async def nudge_interaction(request: Request):
    try:
        data = await request.json()
        user_id = data.get("userId")
        category = data.get("category")
        action = data.get("action") 

        if not user_id or not category:
            return {"status": "error", "message": "Missing userId or category"}

        # 1. Field select (Alpha/Beta)
        field = f"nudge_stats.{category}.alpha" if action == "read" else f"nudge_stats.{category}.beta"

        # 2. MongoDB Update (Sare counters increment honge)
        update_query = {
            "$inc": {
                field: 1,
                "total_success": 1 if action == "read" else 0,
                "total_failure": 1 if action == "dismiss" else 0,
                "total_interactions": 1
            },
            "$set": {
                "last_active": datetime.utcnow() # Monthly tracking ke liye
            }
        }

        users_collection.update_one({"_id": ObjectId(user_id)}, update_query)

        # 3. Calculation ke liye fresh data uthayein
        user = users_collection.find_one({"_id": ObjectId(user_id)})
        t_success = user.get("total_success", 0)
        t_failure = user.get("total_failure", 0)
        
        total_attempts = t_success + t_failure
        new_success_rate = t_success / total_attempts if total_attempts > 0 else 0.0

        # 4. LEVEL UP LOGIC (70% Threshold check)
        current_level = user.get("user_level", "Beginner")
        if new_success_rate >= 0.70 and current_level == "Beginner":
            new_level = "Intermediate"
            users_collection.update_one(
                {"_id": ObjectId(user_id)},
                {"$set": {"user_level": new_level, "level_up_date": datetime.utcnow()}}
            )
            print(f"🎊 LEVEL UP! {user_id} is now {new_level}")

        # 5. Final Rate Save
        users_collection.update_one(
            {"_id": ObjectId(user_id)},
            {"$set": {"success_rate": new_success_rate}}
        )

        print(f"✅ AI Sync: {category} | Rate: {new_success_rate:.2f} | Level: {user.get('user_level', 'Beginner')}")
        
        return {
            "status": "success", 
            "current_success_rate": new_success_rate,
            "total_success": t_success,
            "total_failure": t_failure,
            "level": user.get("user_level", "Beginner")
        }

    except Exception as e:
        print(f"❌ Backend Error: {e}")
        return {"status": "error", "message": str(e)}
# -----------------------------------------------------------
# ✅ CLEAN TEST ROUTE (No Hardcoded Messages)
# -----------------------------------------------------------
@app.get("/test-real-logic/{user_id}")
async def test_real_logic(user_id: str):
    # Ye wahi upar wala real logic chalaye ga testing ke liye
    return await get_nudge(user_id)
# ✅ AUTOMATED NUDGE FUNCTION (Ye har user ke liye check karega)
# ✅ Ye naya aur sahi tareeqa hai
async def auto_check_nudges():
    print("⏰ Checking for pending nudges...")
    # Sirf un users ko uthao jin ka FCM token hai
    users = users_collection.find({"fcm_token": {"$exists": True}})
    
    for user in users:
        user_id = str(user["_id"])
        # ✅ Intelligent Check: Frequency aur Time ke mutabiq
        if is_it_time_to_send(user): 
            print(f"🎯 Time to nudge user: {user.get('email')}")
            # Direct function call (Tez aur professional)
            await get_nudge(user_id)

# --- Ye Function se bahar hona chahiye ---
scheduler = BackgroundScheduler()
scheduler.add_job(lambda: asyncio.run(auto_check_nudges()), 'interval', minutes=2)
scheduler.start()

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)